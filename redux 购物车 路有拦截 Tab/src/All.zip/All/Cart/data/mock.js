import Mock from 'mockjs'
import data from './data.json'
Mock.mock('/list',data)